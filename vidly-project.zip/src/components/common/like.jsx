import React, { Component } from "react";

class Like extends Component {
  state = {};
  render() {
    // return (  );
  }
}

export default Like;
